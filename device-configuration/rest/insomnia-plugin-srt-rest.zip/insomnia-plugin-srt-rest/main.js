// For help writing plugins, visit the documentation to get started:
//   https://docs.insomnia.rest/insomnia/introduction-to-plugins

const cryptoJs = require('crypto-js/crypto-js');
const SHA256 = require('crypto-js/sha256');

module.exports.requestHooks = [
  async (context) => {

    if (context.request.getUrl().indexOf('/api/crown') > -1) {
      return
    }

    let isEnabled = false;

    if (context.request.getEnvironmentVariable('enableAuthentification') != null && context.request.getEnvironmentVariable('enableAuthentification') != '') {
      isEnabled = JSON.parse(context.request.getEnvironmentVariable('enableAuthentification'));
    }

    if (isEnabled && context.request.getMethod().toUpperCase() === 'POST' && !(context.request.getUrl().indexOf('getChallenge') > -1)) {

      const challengeInfo = await _fetchChallenge(context);

      const requestedVariable = context.request.getUrl().substring(context.request.getUrl().indexOf('api/') + 4).trim();

      const body = context.request.getBody();
      const bodyContent = JSON.parse(body.text);

      const newBody = {
        header: _generateRequestHeader(requestedVariable, challengeInfo),
        data: bodyContent.data
      }
      body.text = JSON.stringify(newBody);

      context.request.setBody(body);
    }
  }
];

async function _fetchChallenge(context) {
  const response = await fetch(`http://${context.request.getEnvironmentVariable('address')}/api/getChallenge`, {
    method: 'POST',
    body: JSON.stringify({ data: { user: context.request.getEnvironmentVariable('user') } }),
    headers: {
      'Content-Type': 'application/octet-stream',
    },
  });



  const challenge = (await response.json()).challenge;

  let password = context.request.getEnvironmentVariable('password');
  let user = context.request.getEnvironmentVariable('user');

  let ha1;
  if (challenge.salt == null) {
    ha1 = SHA256(`${user}:${challenge.realm}:${password}`).toString();
  } else {
    const ha1part1 = cryptoJs.lib.WordArray.create(_uint8`${user}:${challenge.realm}:${password}:`);
    const salt = cryptoJs.lib.WordArray.create(new Uint8Array(challenge.salt));
    ha1 = SHA256(ha1part1.concat(salt)).toString();
  }
  const challengeHader = {
    nonce: challenge.nonce,
    opaque: challenge.opaque,
    realm: challenge.realm,
    salt: challenge.salt,
    ha1,
    user,
  };

  return challengeHader;
}

function _uint8(strings, ...subst) {
  const arr = [];
  for (let i = 0; i < strings.raw.length; i++) {
    arr.push(strings.raw[i]);
    arr.push(`${subst[i] || ''}`);
  }
  const charList = arr
    .join('')
    .split('')
    .map((value) => value.charCodeAt(0));
  return new Uint8Array(charList);
}

function _generateRequestHeader(name, challengeInfo) {
  return {
    nonce: challengeInfo.nonce,
    opaque: challengeInfo.opaque,
    realm: challengeInfo.realm,
    response: _getResponseChallenge(name, challengeInfo.ha1, challengeInfo.nonce),
    user: challengeInfo.user,
  };
}

function _getResponseChallenge(name, ha1, nonce) {
  const ha2 = SHA256(`POST:${name}`).toString();
  return SHA256(`${ha1}:${nonce}:${ha2}`).toString();
}
